function validate(){
var username = document.getElementById("username").value;
var password = document.getElementById("password").value;
if ( username == "Ritik" && password == "120499"){
alert ("Login successfully");
window.location = "menu.html"; // Redirecting to other page.
return false;
}
else{
alert("Login failed")
}
}